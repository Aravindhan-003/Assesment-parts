package Collection_prgm;

import java.util.*;

public class Collection_prgm{
	public static void main(String[] args) {
		
		//creating arraylist
		
		List<String> city=new ArrayList();   
	      city.add("Hyderabad");
	      city.add("Noida");
	      city.add("Bangalore");
	      city.add("Chennai");
	      city.add("Delhi");
	      //city.clear();
	      for(int i=0;i<city.size();i++) {
	      System.out.print(city.get(i)+" "); 
	      }
		
		//creating vector
	      System.out.println();
	      System.out.println("Vector");
	      Vector<Integer> v = new Vector();
	      v.addElement(15); 
	      v.addElement(30); 
	      v.addElement(45); 
	      v.addElement(60);
	      
	      v.removeElement(30);
	      //v.clear();
	      for(int i=0;i<v.size();i++) {
		      System.out.println(v.get(i)); 
		      }
	      
	      
		//creating linkedlist
	      System.out.println("LinkedList");
	      LinkedList<String> names=new LinkedList<String>();  
	      names.add("Babu");  
	      names.add("Vanu");  
	      names.add("Gowri");  
	      names.add("Dolly");
	      names.add("Wlex");  
	     
	      names.remove("Gowri");
	      names.remove("Vanu");

	      Iterator<String> itr=names.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	      }
	      
	       
	      //creating stack  
	       
	     Stack<String> S=new Stack<String>();
	     S.push("ramu");
	     S.push("somu");
	     S.push("rahul");
	     S.push("Raja");
	     S.pop();
	     System.out.println(S.isEmpty());
	     System.out.println(S.peek());
	     Iterator<String> it=S.iterator();  
	      while(it.hasNext()){  
	       System.out.print(it.next()+" ");  
	      }

	     
	       //creating linkedhashset
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(11);  
	       set2.add(13);  
	       set2.add(12);
	       set2.add(14);	
	       for(int s:set2) {
	       System.out.print(s+" ");
	       }
	      	}
	      }
