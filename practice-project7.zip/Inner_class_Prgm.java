package Java_oops;
class Employee{
	int salary=10000 ;
	
	class PermEmployee{
		String code="PE01";
		float hike=salary+salary*(float)0.45f;
		
		void New_salary() {
			System.out.println("New salary is:"+hike);
		}
		void display() {
			System.out.println("PermEmp salary is:"+salary+" and code is:"+code+" Salary hike is:"+hike);
		}
	}
	class TempEmployee{
		String code="TE01";
		float hike=salary+salary*(float)0.30f;
		
		void New_salary() {
			System.out.println("New salary is:"+hike);
		}
		void display() {
			System.out.println("TempEmp salary is:"+salary+" and code is:"+code+" Salary hike is:"+hike);
		}
	}
	void role() {
	class ContractEmployee{
		String code="C";
		float hike=salary+salary*(float)0.30f;
		
		void New_salary() {
			System.out.println("New salary is:"+hike);
		}
		void display() {
			System.out.println("ContEmp salary is:"+salary+" and code is:"+code+" Salary hike is:"+hike);
		}
	  }
	ContractEmployee cemp=new ContractEmployee();
	cemp.New_salary();
	cemp.display();
	}
}
public class Inner_class_Prgm {

	public static void main(String[] args) {
		Employee emp=new Employee();
		
		Employee.PermEmployee obj=emp.new PermEmployee();  //inner class
		obj.New_salary();
		obj.display();
		Employee.TempEmployee obj1=emp.new TempEmployee();  //inner class
		obj1.New_salary();
		obj1.display();
		
		emp.role();
		
	}

}
