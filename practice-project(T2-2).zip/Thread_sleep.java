package Thread_prgm;

public class Thread_sleep extends Thread{  
	
	 public void run(){  
	  for(int i=1;i<5;i++){  
	    try{
	    		Thread.sleep(2000);  // 2000 milliseconds = 2secs
	    	}
	    catch(InterruptedException e)
	    {
	    	System.out.println(e);
	    }  
	    System.out.println(Thread.currentThread().getName()+ "  :"+ i);  
	  }  
	 }  
	 
	 public static void main(String args[]){  
		 Thread_sleep t1=new Thread_sleep();  
	  t1.setName("Thread_1");
	  
	  Thread_sleep t2=new Thread_sleep();  
	  t2.setName("Thread_2");
	  
	  Thread_sleep t3=new Thread_sleep(); 
	  t3.setName("Thread_3");
	  
	  Thread_sleep t4=new Thread_sleep(); 
	  t4.setName("Thread_4");
	   
	  t1.start();    
	  t2.start();  
	  t3.start();   
	  t4.start();
	
	  
	 }  
	}  
