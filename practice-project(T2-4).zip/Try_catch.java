package Exception_handling;

public class Try_catch {   //Exception handling prgm

	public static void main(String[] args) {
	int num1=10,num2=0,num3;
	try {
		num3=num1/num2;
		System.out.println("Division of two number:"+num3);
	}
//	catch(NullPointerException ae) {
//		System.out.println("You entered the wrong value");
//		System.out.println(ae.getMessage());
//	}
	catch(Exception e) {
		System.out.println("subclass of ae");
		System.out.println(e.getMessage());
	}
    finally {
    	num3=num1+num2;
    	System.out.println("Final output of addition");
    }
	}

}
