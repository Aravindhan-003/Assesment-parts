package String_Program;

public class String_Buffer {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Started Java");
		StringBuilder sb1=new StringBuilder("Phase1 Java");
		
		sb.append("Phase1");
		System.out.println(sb);
		
		sb1.append("Phase2");
		System.out.println(sb1);
		
		sb.delete(2, 5);
		System.out.println(sb);
		
		sb.replace(5, 9, "Python");
		System.out.println(sb);
		
		sb.insert(5,"language");
		System.out.println(sb);
		
		sb.reverse();
		System.out.println(sb);
		
		sb.charAt(9);
		System.out.println(sb);
		
//		StringBuffer sb1 = new StringBuffer("Hello");
//		 StringBuffer sb2 = new StringBuffer("Hello");
//		 System.out.println(sb1.equals(sb2));
//		 
//		 String str1 = new String("Hello");
//		 String str2 = new String("Hello");
//		 System.out.println(str1.equals(str2));
	}

}
