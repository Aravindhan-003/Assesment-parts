package sample;
import java.util.regex.*;
public class Regex_prgm {

	public static void main(String[] args) {
		String str="ch.ck";    //check it will return true
		String str1="check";
		
		// using compile()
		Pattern pattern=Pattern.compile(str);
		Matcher match=pattern.matcher(str1);
		boolean k=match.matches();
		if(k) {
			System.out.println("Matching");
		}
		else {
			System.out.println("Not matching");
		}
		
		String str2="c";
		//using matches();
		boolean st=Pattern.matches("[^abx]",str2);   //it check only char
		System.out.println(st);
		
		boolean st1=Pattern.matches("[a-zA-Z]",str);   //it check String
		System.out.println(st1);
		
		 System.out.println(Pattern.matches(".k", "ak"));//true (2nd char is s)  
	     System.out.println(Pattern.matches(".p", "mk"));//false (2nd char is not s) 
		
		String e="dfghSD1898.ghjmail.com";
		System.out.println(Pattern.matches("[a-zA-Z]{6}+\\d{4}[.][a-z]{7}[.][a-z]{3}", e));
		
		 System.out.println(Pattern.matches("\\d", "abc"));//false (non-digit)  
	     System.out.println(Pattern.matches("\\d", "1"));//true (digit and comes once) 
		
		 System.out.println(Pattern.matches("\\D", "123abc"));//false (digit and char)  
	     System.out.println(Pattern.matches("\\D", "o"));//true (non-digit and comes once)
	}

}
