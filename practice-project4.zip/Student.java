package constructor;

public class Student {
	String name; 
    int age;
    char section;
    char gender;
    int total=0;
    int percentage=0;
    int subject_1=0,subject_2=0,subject_3=0;
    
    Student(int subject_1,int subject_2,int subject_3,String n,int k,char l,char m){
         this.name=n;
         this.age=k;
         this.section=l;
         this.gender=m;
    	 total=subject_1+subject_2+subject_3;
    	 percentage=total/3;
    }
    Student(int subject_2,int subject_3,String n,int k,char l,char m){
    	   this.name=n;
    	   this.age=k;
    	   this.section=l;
    	   this.gender=m;
    	   total=subject_2+subject_3+subject_1;
    	   percentage=total/3;
    	    }
    
    void display() {
    	System.out.println("NAME:"+name +" "+ "AGE:"+age+ " "+"Section:"+section+" "+ "Gender:"+gender);
    	System.out.println("Total marks is: "+total);
    	System.out.println("Percentage is:"+percentage);
    }
	
	
    public static void main(String args[]) {
    	Student s1=new Student(80,80,80,"Rahul",21,'D','M');
    	Student s2=new Student(90,80,"Rani",21,'G','F');
    	Student s3=new Student(80,80,"priya",21,'A','F');
    	Student s4=new Student(50,90,90,"Ramesh",21,'E','M');
    	
    	s1.display();
    	s2.display();
    	s3.display();
    	s4.display();
    	
    }
}
