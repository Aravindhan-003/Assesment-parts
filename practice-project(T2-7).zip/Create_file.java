package File_handling;
import java.io.*;
public class Create_file {
	
	  void Read() throws IOException { //read data
	FileInputStream fin=new FileInputStream("F:\\Mphasis\\New folder (2)\\0.7 eBook\\win.txt");
	  int ch;
	  while((ch=fin.read())!=-1) {
		  System.out.print((char)ch);
	  }
  }
	public static void main(String[] args) throws IOException{
		Create_file f=new Create_file();

		
		File file= new File("F:\\Mphasis\\New folder (2)\\0.7 eBook\\win.txt");
		try {
			if(file.createNewFile()) {  //create file
				System.out.println("File created");
			}
			else {
				if(file.exists()) {
					 //to delete file
					    //file.delete();
						//System.out.println("file deleted");
						
					DataInputStream dis=new DataInputStream(System.in);
					FileOutputStream fos=new FileOutputStream("F:\\Mphasis\\New folder (2)\\0.7 eBook\\win.txt",true);
					BufferedOutputStream bos=new BufferedOutputStream(fos);
					System.out.println("Enter data:");
					char ch;   
					
					while((ch=(char)dis.read())!='%') {  //update data
						bos.write(ch);
					}
					bos.close();
					f.Read();
			  }
			}
		} catch (IOException e) {
			 
			e.printStackTrace();
		}

	}
}
