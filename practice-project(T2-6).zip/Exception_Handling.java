package Exception_handling;

import java.util.Scanner;

class Handling extends Exception{
	void display(int num1,int num2) {
		int num;
		if(num2==0) {
			throw new ArithmeticException("Second number is invalid(zero)");
		}
		else {
		num=num1/num2;
		System.out.println(num);
		}
		
	}
}
public class Exception_Handling {

	public static void main(String[] args) {
		Handling h=new Handling();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first Number:");
		int num1=sc.nextInt();
		System.out.println("Enter second Number:");
		int  num2=sc.nextInt();
		try {
			h.display(num1,num2);
		}
		catch(ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("The Exception is handled");
		}

	}

}
