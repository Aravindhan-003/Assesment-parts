package Collection_prgm;

import java.util.*;
public class Array_prgm {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your limit:");
		int n=sc.nextInt();
		int[] arr=new int[n];	
		
		for(int i=0;i<n;i++) {
			System.out.println("Enter Number:");
			arr[i]=sc.nextInt();
		}
		
		double[] dbl = {10.5,98.9,56.6,34.4,65.45};

	      // Print all the array elements
	      for (int i = 0; i < dbl.length; i++) {
	         System.out.println(dbl[i]);
	      }

	      //find max number 
	      double max = dbl[0];
	      for (int i = 1; i < dbl.length; i++) {
	         if (dbl[i] > max) 
	        	 {
	        	    max = dbl[i];
	        	 }
	      }
	      System.out.println("Max is " + max); 
	}

}
