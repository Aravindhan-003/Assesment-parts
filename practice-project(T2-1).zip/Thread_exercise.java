package Thread_prgm;

public class Thread_exercise extends Thread {

	public void run() {
	  	System.out.println("This is thread block");
	}
	
	public static void main(String[] args) {
		Thread_exercise te=new Thread_exercise();
		te.start();

	}

}
