package Thread_prgm;

public class Runnable_prgm implements Runnable {
	public void run(){  
		System.out.println("This is thread block");  
		try {
			Thread.sleep(2000);
		}
		catch(Exception e) {
		System.out.println(e.getMessage());	
		}  
		}
		  
		public static void main(String args[]){  
		Runnable_prgm m1=new Runnable_prgm(); 
		Thread t1 = new Thread(m1);       // we are passing the object into the thread class constructor
		
		
		t1.start();                                     
	 }  
}
