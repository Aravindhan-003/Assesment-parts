package accessmodifier_A;

public class classP {
	public void methodPublic() {
		System.out.println("This is methodPublic classP");
		methodPrivate();
	}

	protected void methodProtected() {
		System.out.println("This is methodProtected classP");
		methodPrivate();
		
	}

	void methodDefault() {
		System.out.println("This is methodDefault classP");
		methodPrivate();
	}

	private void methodPrivate() {
		System.out.println("This is methodPrivate classP");
	}

	public static void main(String args[]){
	
		  new classN().methodprotect();
		  new classN().methodpublic();
		  new classN().method_default();
		  
		  new classM().methodprotect();
		  new classM().method_default();
		  
		  //Variables of N 
		  System.out.println("public method classN:" +new classN().i1);
		  System.out.println( "method default classN:"+new classN().d);
		  System.out.println("protected method classN:"+ new classN().l2);
		  
		  // variables of M
		  System.out.println("default method classN:" +new classM().l);
		  System.out.println("protected method classN:"+ new classM().f);
	  }
}
