package accessmodifier_A;

public class classM {
	private int i=30;
	  long l=234;
	  protected float f=3.14f;
	  
	    public void methodpublic() {
	    	System.out.println("This is public method classM");
	    	methodprivate();
	    }
	    
		protected void methodprotect() {
			System.out.println("This is protected method classM:"+f);
			methodprivate();
		}
		
		private void methodprivate() {
			System.out.println("This is private method classM:"+i);
			
		}
		
		void method_default() {
			System.out.println("This is method default classM:"+l);
			methodprivate();
		}
}
