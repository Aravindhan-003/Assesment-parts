package accessmodifier_A;

public class classN {
	public int i1=31;
	  double d=23456;
	  protected long l2=313;
	  
	    private void methodprivate() {
	    	System.out.println("This is private method classN");
	    }
	 
		protected void methodprotect() {
			System.out.println("This is protected method classN:"+l2);
			methodprivate();
		}
		
		public void methodpublic(){
			System.out.println("This is public method classN:"+i1);
			methodprivate();
		}
		
		void method_default() {
			System.out.println("This is method default classN:"+d);
			methodprivate();
		}
}
