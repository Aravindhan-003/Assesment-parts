package accessmodifier_B;

public class classX {
	 private int i3=33;
	 long l3=234;
	 protected float f2=3.34f;
	 public char c='d';
	 
}
