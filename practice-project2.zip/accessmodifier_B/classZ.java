package accessmodifier_B;

import accessmodifier_A.classM;
import accessmodifier_A.classN;
import accessmodifier_A.classP;


public class classZ extends classP{
	public static void main(String args[]){
		
		System.out.println("default method classX:" +new classX().l3);
		System.out.println("protected method classX:" +new classX().f2);
	    System.out.println("public method classX:" +new classX().c);
	
		 new classZ().methodPublic();
		 new classZ().methodProtected();
		 new classN().methodpublic();
		 new classM().methodpublic();
	  }
}
